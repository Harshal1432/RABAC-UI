import React, { useEffect, useState } from 'react';
import { fetchRoles, addRole, deleteRole } from '../api';

const RoleManagement = () => {
    const [roles, setRoles] = useState([]);
    const [newRole, setNewRole] = useState({ name: '', permissions: [] });

    useEffect(() => {
        fetchRoles().then(setRoles);
    }, []);

    const handleAddRole = () => {
        if (newRole.name) { // Ensure the role name is filled
            addRole(newRole).then(role => {
                setRoles([...roles, role]);
                setNewRole({ name: '', permissions: [] });
            });
        }
    };

   const confirmDeleteRole = (id) => {
        if (window.confirm("Are you sure you want to delete this role?")) {
            handleDeleteRole(id);
        }
   };

   const handleDeleteRole = (id) => {
       deleteRole(id).then(() => {
           setRoles(roles.filter(role => role.id !== id));
       });
   };

   return (
       <div>
           <h2>Role Management</h2>
           <input 
               type="text" 
               placeholder="Role Name" 
               value={newRole.name} 
               onChange={e => setNewRole({ ...newRole, name: e.target.value })} 
           />
           <button onClick={handleAddRole}>Add Role</button>
           <ul>
               {roles.map(role => (
                   <li key={role.id}>
                       {role.name} - Permissions: {role.permissions.join(', ')}
                       <button onClick={() => confirmDeleteRole(role.id)}>Delete</button>
                   </li>
               ))}
           </ul>
       </div>
   );
};

export default RoleManagement;