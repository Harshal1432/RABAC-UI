import React, { useEffect, useState } from 'react';
import { fetchUsers, addUser, updateUser, deleteUser } from '../api';

const UserManagement = () => {
    const [users, setUsers] = useState([]);
    const [newUser, setNewUser] = useState({ name: '', role: '', status: 'Active' });
    const [isEditing, setIsEditing] = useState(false);
    const [editingUser, setEditingUser] = useState(null);

    useEffect(() => {
        fetchUsers().then(setUsers);
    }, []);

    const handleAddUser = () => {
        if (newUser.name && newUser.role) { // Ensure both fields are filled
            addUser(newUser).then(user => {
                setUsers([...users, user]);
                setNewUser({ name: '', role: '', status: 'Active' });
            });
        }
    };

    const handleEditUser = (user) => {
        setIsEditing(true);
        setEditingUser(user);
        setNewUser({ name: user.name, role: user.role });
    };

    const handleSaveUser = () => {
        if (editingUser) {
            updateUser({ ...editingUser, name: newUser.name, role: newUser.role }).then(() => {
                setUsers(users.map(user => user.id === editingUser.id ? { ...editingUser, name: newUser.name, role: newUser.role } : user));
                setNewUser({ name: '', role: '' });
                setIsEditing(false);
                setEditingUser(null);
            });
        }
    };

    const handleToggleStatus = (user) => {
        const updatedStatus = user.status === 'Active' ? 'Inactive' : 'Active';
        updateUser({ ...user, status: updatedStatus }).then(() => {
            setUsers(users.map(u => u.id === user.id ? { ...u, status: updatedStatus } : u));
        });
    };

    const confirmDelete = (id) => {
        if (window.confirm("Are you sure you want to delete this user?")) {
            handleDeleteUser(id);
        }
    };

    const handleDeleteUser = (id) => {
        deleteUser(id).then(() => {
            setUsers(users.filter(user => user.id !== id));
        });
    };

    return (
        <div>
            <h2>User Management</h2>
            <input 
                type="text" 
                placeholder="Name" 
                value={newUser.name} 
                onChange={e => setNewUser({ ...newUser, name: e.target.value })} 
            />
            <input 
                type="text" 
                placeholder="Role" 
                value={newUser.role} 
                onChange={e => setNewUser({ ...newUser, role: e.target.value })} 
            />
            {isEditing ? (
                <>
                    <button onClick={handleSaveUser}>Save User</button>
                    <button onClick={() => {setIsEditing(false); setNewUser({ name: '', role: '' });}}>Cancel</button>
                </>
            ) : (
                <button onClick={handleAddUser}>Add User</button>
            )}
            <ul>
                {users.map(user => (
                    <li key={user.id}>
                        <span>{user.name} - {user.role} - {user.status}</span>
                        <div>
                            <button className="edit-button" onClick={() => handleEditUser(user)}>Edit</button>
                            <button onClick={() => handleToggleStatus(user)}>
                                {user.status === 'Active' ? 'Deactivate' : 'Activate'}
                            </button>
                            <button onClick={() => confirmDelete(user.id)}>Delete</button>
                        </div>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default UserManagement;