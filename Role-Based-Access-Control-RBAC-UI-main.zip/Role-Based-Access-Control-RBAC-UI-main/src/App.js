import React from 'react';
import UserManagement from './UserManagement';
import RoleManagement from './RoleManagement';

const MainApp = () => {
    return (
        <div className="App">
            <h1>RBAC Admin Dashboard</h1>
            <UserManagement />
            <RoleManagement />
        </div>
    );
};

export default MainApp;