let users = [
    { id: 1, name: 'HARSHAL', role: 'Admin', status: 'Active' },
    { id: 2, name: '', role: 'User', status: 'Inactive' },
];

let roles = [
    { id: 1, name: 'Admin', permissions: ['Read', 'Write', 'Delete'] },
    { id: 2, name: 'User', permissions: ['Read'] },
];

export const fetchUsers = () => Promise.resolve(users);
export const fetchRoles = () => Promise.resolve(roles);

export const addUser = (user) => {
    users.push({ id: users.length + 1, ...user });
    return Promise.resolve(user);
};

export const updateUser = (updatedUser) => {
    users = users.map(user => user.id === updatedUser.id ? updatedUser : user);
    return Promise.resolve(updatedUser);
};

export const deleteUser = (id) => {
    users = users.filter(user => user.id !== id);
    return Promise.resolve();
};

export const addRole = (role) => {
    roles.push({ id: roles.length + 1, ...role });
    return Promise.resolve(role);
};

export const updateRole = (updatedRole) => {
    roles = roles.map(role => role.id === updatedRole.id ? updatedRole : role);
    return Promise.resolve(updatedRole);
};

export const deleteRole = (id) => {
    roles = roles.filter(role => role.id !== id);
    return Promise.resolve();
};